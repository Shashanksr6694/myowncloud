#!/usr/bin/python2 
import os
os.system('vncviewer 192.168.43.98:5903')