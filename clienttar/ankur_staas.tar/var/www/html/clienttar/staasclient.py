
 import commands 
commands.getoutput('yum install fuse-sshfs') 
commands.getoutp('systemctl restart sshfs')
commands.getoutput('systemctl restart sshd') 
commands.getoutput('mkdir /root/Desktop/ankur ') 
 commands.getoutput('sshfs ankur@192.168.43.98:/ankur /root/Desktop/ankur ') 
 